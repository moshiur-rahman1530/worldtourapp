

<?php $__env->startSection('content'); ?>


 <!--Tours -->
 <div class="Tours">
         <div class="container">
                  <div class="titlepage">
                     <h2>All Tour Package List</h2>
                     
                  </div>


                  <div class="row">
                     <?php $__currentLoopData = $tours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6 col-sm-12 pb-1 removeClass mb-3" id="removeClass">
                              <div class="item text-center text-md-left"> 
                                 <div class="divimgres">
                                    <img class="img-responsive resimg" src="<?php echo e($tour->tour_img); ?>" alt="#" />
                                 </div>
                                 <h3>
                                    <?php echo e($tour->tour_title); ?>

                                 </h3>
                                 <p>
                                    <?php echo e(Str::limit($tour->tour_des, 200, $end='...')); ?>

                                 </p> 
                                 <a href="<?php echo e(url('/tourpage/'.$tour->id)); ?>" class="readmorebtn">Read More</a>
                              </div>
                        </div>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
         </div>
   </div>
          
      <!-- end Tours -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>


</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-projects\empty-project\tourmanagement-app\resources\views/alltour.blade.php ENDPATH**/ ?>