

<?php $__env->startSection('content'); ?>


 <!--Tours -->
 <div class="Tours">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="titlepage">
                     <h2>Details For : <?php echo e($data->cat_name); ?></h2>
                     
                  </div>
               </div>
            </div>
            <section id="demos">
               <div class="row text-center">
                  <div class="col-md-12">
                     
                        <div class="item">
                           <div class="detailsimage mb-3">
                              <img class="img-responsive img-fluid" src="<?php echo e($data->cat_img); ?>" alt="#" />
                           </div>
                           <h3><?php echo e($data->cat_name); ?></h3>
                          
                           <p>Description:</p>
                           <p><?php echo e($data->cat_des); ?></p>
                        </div>
                  </div>
               </div>
            </section>
         </div>
      </div>
      <!-- end Tours -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">

    


</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-projects\empty-project\tourmanagement-app\resources\views/detailscategory.blade.php ENDPATH**/ ?>