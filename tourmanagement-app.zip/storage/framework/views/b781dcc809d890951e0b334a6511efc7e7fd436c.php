

<?php $__env->startSection('content'); ?>


 <!--Tours -->
 <div class="Tours">
         <div class="container">
            <div class="row">
               <div class="col-md-12">
                  <div class="titlepage">
                     <h2>Details For : <?php echo e($data->tour_title); ?></h2>
                     
                  </div>
               </div>
            </div>
            <section id="demos">
               <div class="row">
                  <div class="col-md-12">
                     
                        <div class="item detailtourstyle">
                           <div class="detailsimage mb-3">
                              <img class="img-responsive img-fluid" src="<?php echo e($data->tour_img); ?>" alt="#" />
                           </div>
                           <h3><?php echo e($data->tour_title); ?></h3>
                           <p>Price: <?php echo e($data->price); ?></p>
                           <p>Duration: <?php echo e($data->duration); ?></p>
                           
                           <p>Travel Posible Date: <?php echo e($data->date); ?></p>
                           <p>Description:</p>
                           <p><?php echo e($data->tour_des); ?></p>


                          <div class="bookContainer">
                              <a id="bookTour" data-id="<?php echo e($data->id); ?>" class="bookTour mr-4">Book Now</a><a href="<?php echo e(url('/all-tours')); ?>" class="bookTour">Get More</a>
                              <!-- <a href="<?php echo e(url('/bookTour/'.$data->id)); ?>" id="bookTour" data-id="<?php echo e($data->id); ?>" class="bookTour mr-4">Book Now</a><a href="#" class="bookTour">Get More</a> -->
                          </div>
                           
                        </div>
                  </div>
               </div>
            </section>
         </div>
      </div>
      <!-- end Tours -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>

$(document).ready(function() {
   $('#bookTour').click(function(e){
      e.preventDefault();
      const id = $(this).data('id');
      const url = `/bookTour/${id}`;
      axios.get(url).then(function(response){
         if (response.data==1) {
            toastr.success('You Successfully Booked Tour.');
         } else if(response.data==2) {
            toastr.warning('Already booked this tour.')
         }else {
            toastr.error('Failled.')
         }
            
      }).catch(function(error){
         console.log(error);
      })
   })
})

</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-projects\empty-project\tourmanagement-app\resources\views/detailstour.blade.php ENDPATH**/ ?>